package fr.xebia.techevent.hadoop.job.error;

import fr.xebia.techevent.hadoop.job.AccessLog;
import fr.xebia.techevent.hadoop.job.LogParser;
import fr.xebia.techevent.hadoop.job.error.model.ErrorInfo;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;


public class SearchCodeMapper extends Mapper<LongWritable, Text, ErrorInfo, IntWritable> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        AccessLog accessLog = LogParser.parseAccessLog(value.toString());

        String expectedErrorCode = nullSafeErrorCode(context);
        if (expectedErrorCode.equals(accessLog.returnCode)) {
            ErrorInfo errorInfo = new ErrorInfo(
                    new Text(accessLog.returnCode),
                    new Text(accessLog.resources),
                    new Text(accessLog.timestamp.split(":")[1]));
            context.write(errorInfo, new IntWritable(1));
        }
    }

    private String nullSafeErrorCode(Context context) {
        String errorCode = context.getConfiguration().get("ERROR_CODE");

        return errorCode == null ? "" : errorCode;
    }
}
