package fr.xebia.techevent.hadoop.job.error.model;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * TODO
 * - la classe doit impl�menter WritableComparable
 * - il faut impl�menter les m�thodes obligatoires
 */

public class ErrorInfo implements WritableComparable {

    private Text error;

    private Text resources;

    private Text hour;

    public ErrorInfo() {
        this.error = new Text();
        this.resources = new Text();
        this.hour = new Text();
    }

    public ErrorInfo(Text error, Text resources, Text hour) {
        this.error = error;
        this.resources = resources;
        this.hour = hour;
    }

    public Text getError() {
        return error;
    }

    public void setError(Text error) {
        this.error = error;
    }

    public Text getResources() {
        return resources;
    }

    public void setResources(Text resources) {
        this.resources = resources;
    }

    public Text getHour() {
        return hour;
    }

    public void setHour(Text hour) {
        this.hour = hour;
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof ErrorInfo) {
            ErrorInfo that = (ErrorInfo) o;
            if (this.equals(that))
                return 0;
            else if (this.error.compareTo(that.error) < 0 || this.resources.compareTo(that.resources) < 0 || this.hour.compareTo(that.resources) < 0)
                return -1;
            else
                return 1;
        }
        return 2;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ErrorInfo errorInfo = (ErrorInfo) o;

        if (error != null ? !error.equals(errorInfo.error) : errorInfo.error != null) return false;
        if (hour != null ? !hour.equals(errorInfo.hour) : errorInfo.hour != null) return false;
        if (resources != null ? !resources.equals(errorInfo.resources) : errorInfo.resources != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = error != null ? error.hashCode() : 0;
        result = 31 * result + (resources != null ? resources.hashCode() : 0);
        result = 31 * result + (hour != null ? hour.hashCode() : 0);
        return result;
    }

    @Override
    public void write(DataOutput dataOutput) throws IOException {
        error.write(dataOutput);
        resources.write(dataOutput);
        hour.write(dataOutput);
    }

    @Override
    public void readFields(DataInput dataInput) throws IOException {
        error.readFields(dataInput);
        resources.readFields(dataInput);
        hour.readFields(dataInput);
    }

    @Override
    public String toString() {
        return "ErrorInfo{" +
                "error=" + error +
                ", resources=" + resources +
                ", hour=" + hour +
                '}';
    }
}
