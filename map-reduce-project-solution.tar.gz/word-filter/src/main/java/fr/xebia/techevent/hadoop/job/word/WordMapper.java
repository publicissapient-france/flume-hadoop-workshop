package fr.xebia.techevent.hadoop.job.word;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import fr.xebia.techevent.hadoop.job.AccessLog;
import fr.xebia.techevent.hadoop.job.LogParser;

import java.io.IOException;

public class WordMapper extends Mapper<LongWritable, Text, Text, Text> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        AccessLog accessLog = LogParser.parseAccessLog(value.toString());
        String wordToBeFiltered = nullSafeWordToBeFiltered(context);
        if(accessLog.resources.contains(wordToBeFiltered)) {
            context.write(new Text(accessLog.resources), value);
        }
    }

    private String nullSafeWordToBeFiltered(Context context) {
        String errorCode = context.getConfiguration().get("WORD_TO_BE_FILTERED");

        return errorCode == null ? "" : errorCode;
    }
}
